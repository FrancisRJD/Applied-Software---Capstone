# Project's .gitignore should now function THIS TIME and not be a complete mess! If uneditable files that shouldn't be pushed up to the repo are getting pushed, give me (Francis) a heads up so I can make sure it's ripped out of the repo and added to the .gitignore list!

## TODO
### OVERARCHING (Arranged in importance)
- Add new/updating old features(CRITICAL for Minimum Viable Product)
	- Needs to be added
		- View Tournaments
			- Create button that leads to create tournament form
			- List of tournaments showing tournament names, watcher capacity, team capacity, and how many teams have registered(And paid?)
			- Edit button next to each listing to lead to editting tournament
		- Create Tournament
			- Simple tournament creation form. User enters in tournament name, date, location, team capacity, and watcher capacity.
		- Edit Tournament
			- Similar as above but updates pre-existing tournament based on hidden ID put into the form by tournament list view
	- Needs to be adjusted
		- Team Registration Page
			- Needs work in view and domain to work off of new V2 database and related V2 entities(PlayerV2, TeamV2)
			- Needs a new field to select which tournament the team is registering for
			- Note from Francis: When generating a registration, you will first need to create the new team, followed by its players, and then add a new registration)
		- Admin Team List
			- Delete and Mark Paid needs to work with new V2 database (Mark paid will now update the new "Registration" table's status instead of the old "Team", as teams no longer have markings for whether they've paid or not)
			- Needs to list teams from the new database and interact with that instead of the old one
			- Teams should now display which tournament(s) they're registered to
		- Team Details
			- Should now list what tournament(s) the team has registered and paid for
- Determine whether user authorization should be verified in View or strictly in Domain
	- Should User.HasClaim() and related calls be moved to Domain?
- Figure out if the JS black magic Nick added in wwwroot will work with our architectural standards/new features
	- Likely fine? Seems perfectly in line with view responsibilities (Shapes player registration data, doesn't apply business rules). Nothing seems to jump out at me as a potential issue.
- Refactor project so it follows current architectural rules (Everything resides in view, everything is tightly-coupled)

### VIEW
- Implement Tournament creation, editting, and view (ADMIN ONLY)
	- Tournament List
	- Create Tournament Form
	- Edit Tournament Form
- Separate Team list view into a team registration view and a team view
	- Registration view is mainly for admins to see new registrations, mark payments, change status, etc
		- Displays from (To-be-added) TeamRegistration table
		- (Non-critical) Probably should also display team details instead of just team ID (For clarity)
	- Teams view is mainly public-facing.
		- Non-admin view should display teams that have PAID status on database
		- Admin view should display all teams and allow for editting (Admin presumed to be the ultimate arbiter of editting/removing stuff basically)
- Alter Team List view to only show teams registered to the current selected tournament
- Refactor controllers to be use result returns from the domain for certain error displays (Anything business rules-related. Unnecessary for "Required" checks and other data-shaping stuff though)
- (Large chunk of the view has already been done by the MVC project so the grand bulk of the View work is in implementing the new views/altering existing views to account for the fact that we're dealing with *multiple* tournaments now)

### DOMAIN
- Move entities out of Models to make them the Domain's responsibility.
- Refactor View controllers to decouple persistence and view, and move business rule checks to itself.
	- Admin Controller
		- Index
		- CreateTeam (GET/POST)
		- EditTeam (GET/POST)
		- DeleteTeam (GET)
		- DeleteTeamConfirmed (POST)
		- UpdatePlayer (POST) - How is this getting called? Seems to be getting editted within Admin>Edit
		- AddPlayer(GET/POST) - Not actually being used? (Instead using wwwroot javascript magic)
		- RemovePlayer (POST)
		- MarkPaid
		- Summary
		- TeamListAdmin
		- DetailsAdmin
	- Home Controller
		- TeamList
		- Details
		- Register (GET/POST)
		- RegisterPlayer - Not actually being used? (Probably same as admin variant?)
- Slated for possible removal (To avoid confusion)
	- Admin Controller
		- > AddPlayer (Unless it's being used by js?)
	- Home Controller
		- > RegisterPlayer (Unless it's being used by js?)
- Auth Controller Refactor (Separate from above controller refactors as this is non-critical, but needed eventually)

### PERSISTENCE
- Update database to follow structure. Make new tables for this instead of altering/updating existing ones so code can gradually migrate to new tables. Make new rebuild DB sql file for this aswell!
	- Player
		- Id - Int
		- TeamId - Int, Foreign Key (Team)
		- Name - String
		- Email - String
		- City - String 
		- Province - String
	- Team
		- Id - Int
		- Name - String
		- DivisionId - Int
		- TournamentId - Int, Foreign Key (Tournament)
	- Tournament
		- Id - Int
		- Name - String
		- TournamentDate - DateTime
		- Location - String
		- TeamCapacity - Int
		- RegistrationOpen - Bool
		- TournamentCapcity - Int (For viewer capacity?)
	- TournamentRegistration
		- Id - Int
		- TournamentId - Int, Foreign Key (Tournament)
		- TeamId - Int, Foreign Key (Team)
		- Status - ENUM RANGE (0 = Unpaid, 1 = Paid) (For verifying if team has paid or not, for now)
		- StatusDate - DateTime (Time of status change)
	- User (Non-critical, but needed)
		- Id - Int
		- UserName - String
		- PasswordHash - String
		- IsAdmin - Bool
- Move DbContext out of the Models folder
- Add Dao(s) for Domain to request read-write from


## Git Cmd Notes To Self
git status - Shows what files are being added, removed, or modified. Doublecheck using this to ensure "Bin", "Obj", "Log", "Build" and other generated non-critical files/folders aren't getting pushed up to the repo!!!

git rm --cached fileExample.txt - Removes a file from the git repo WITHOUT deleting it from your system. (NOTE that you can actually delete things off the github repo directly by just clicking on the file and going to the "more actions" triple-dot menu button in the top right. Just noting this down just incase.)
